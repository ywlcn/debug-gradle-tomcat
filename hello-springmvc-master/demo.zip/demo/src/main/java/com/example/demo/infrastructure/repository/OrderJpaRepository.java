package com.example.demo.infrastructure.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.domain.object.Order;
import com.example.demo.infrastructure.entity.OrderEntity;

/**
 * JPAを利用するためのインタフェース
 */
public interface OrderJpaRepository extends JpaRepository<OrderEntity, Integer> {

	//Optional<OrderEntity> findOwnOrderById(Integer userId, Integer orderId);
	
	List<OrderEntity> findAllByUserId(Integer userId);
}