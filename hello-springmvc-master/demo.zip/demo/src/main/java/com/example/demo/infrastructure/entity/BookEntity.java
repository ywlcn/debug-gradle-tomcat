package com.example.demo.infrastructure.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.example.demo.domain.object.Book;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * RDBレコードのマッピング用クラス
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "test_books", uniqueConstraints = @UniqueConstraint(columnNames = {"id"}))
public class BookEntity {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "bookname")
    private String bookname;
    
    @Column(name = "barcode")
    private String barcode;
    
    @Column(name = "price")
    private Integer price;
    
    @Column(name = "status")
    private String status;
    
    /**
     * ドメインオブジェクトからインスタンスを生成
     *
     * @param book ドメインオブジェクト
     * @return BookEntity
     */
    public static BookEntity build(Book book) {
        return BookEntity.builder()
                .id(book.getId())
                .bookname(book.getBookname())
                .barcode(book.getBarcode())
                .price(book.getPrice())
                .status(book.getStatus())
                .build();
    }

    /**
     * ドメインオブジェクトへ変換
     *
     * @return ドメインオブジェクト
     */
    public Book toDomainBook() {
        return Book.builder()
                .id(this.id)
                .bookname(this.bookname)
                .barcode(this.barcode)
                .price(this.price)
                .status(this.status)
                .build();
    }
}
