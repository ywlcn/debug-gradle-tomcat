package com.example.demo.application.resource;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "アカウント情報")
public class JwtRequest {

    @ApiModelProperty(value = "ユーザ名")
    private String username;

    @ApiModelProperty(value = "パスワード")
    private String password;
}