package com.example.demo.infrastructure.repository;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.domain.exception.NotFoundException;
import com.example.demo.domain.object.Book;
import com.example.demo.domain.repository.BookRepository;
import com.example.demo.infrastructure.entity.BookEntity;

import lombok.RequiredArgsConstructor;

/**
 * 永続化の実装クラス ドメインオブジェクトをEntityに変換してJPAをラップする
 */
@Repository
@RequiredArgsConstructor
public class BookRepositoryImpl implements BookRepository{
	
	private final BookJpaRepository bookJpaRepository;
	
	/**
     * {@inheritDoc}
     */
    @Override
    public Book findById(Integer id) {
        return this.bookJpaRepository.findById(id).orElseThrow(() -> new NotFoundException(id + " is not found."))
                .toDomainBook();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Book save(Book Book) {
        return this.bookJpaRepository.save(BookEntity.build(Book)).toDomainBook();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void deleteById(Integer id) {
        try {
            this.bookJpaRepository.deleteById(id);
        } catch (EmptyResultDataAccessException e) {
            // 削除しようとしたIDが存在しない
            throw new NotFoundException(e.getMessage());
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<Book> findAll() {
        try {
            return this.bookJpaRepository.findAll().stream().map(entity -> entity.toDomainBook()).collect(Collectors.toList());
        } catch (EmptyResultDataAccessException e) {
            // 削除しようとしたIDが存在しない
            throw new NotFoundException(e.getMessage());
        }
    }
}
