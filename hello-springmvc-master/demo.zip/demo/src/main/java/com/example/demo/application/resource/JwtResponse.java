package com.example.demo.application.resource;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "JWTトークン")
public class JwtResponse {

    @JsonProperty("Token")
    @ApiModelProperty(value = "トークン")
    private final String token;
}