package com.example.demo.application.resource;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Value;

/**
 * エラーレスポンスのマッピング用クラス(Json)
 */
@Value
@ApiModel(value = "エラーメッセージ")
@JsonRootName("Error")
@AllArgsConstructor
public class ErrorResponse {

    @JsonProperty("Message")
    @ApiModelProperty(value = "エラーメッセージ")
    private final String message;
    
    @JsonProperty("Detail")
    @ApiModelProperty(value = "エラーの詳しい情報")
    private final String detail;
    
    @JsonProperty("Code")
    @ApiModelProperty(value = "エラーコード")
    private final String code;
}