package com.example.demo.domain.repository;

import java.util.List;

import com.example.demo.domain.object.Order;

public interface OrderRepository {
	/**
     * 注文一覧
     * @return
     */
    List<Order> findAll();
    
	/**
     * 注文一覧
     * 
     * @return
     */
    List<Order> findAllByUserId(Integer userId);
    
    /**
     * 注文検索
     * 
     * @param id ユーザID
     * @param id 検索したい注文ID
     * @return 注文
     */
  //  Order findOwnOrderById(Integer userId, Integer orderId);

    /**
     * 注文検索
     *
     * @param id 検索したい注文ID
     * @return 注文
     */
    Order findById(Integer id);

    /**
     * 注文作成、更新
     *
     * @param Order 作成、更新した注文
     * @return 更新後の注文
     */
    Order save(Order order);

    /**
     * 注文削除
     *
     * @param id 削除したい注文ID
     */
    void deleteById(Integer id);

}
