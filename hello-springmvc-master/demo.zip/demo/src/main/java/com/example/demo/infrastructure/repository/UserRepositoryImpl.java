package com.example.demo.infrastructure.repository;

import java.util.List;
import java.util.stream.Collectors;

import com.example.demo.domain.exception.NotFoundException;
import com.example.demo.domain.object.User;
import com.example.demo.domain.repository.UserRepository;
import com.example.demo.infrastructure.entity.UserEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;

/**
 * 永続化の実装クラス ドメインオブジェクトをEntityに変換してJPAをラップする
 */
@Repository
@RequiredArgsConstructor
public class UserRepositoryImpl implements UserRepository {

    private final UserJpaRepository userJpaRepository;

    /**
     * {@inheritDoc}
     */
    @Override
    public User findById(Integer id) {
        return this.userJpaRepository.findById(id).orElseThrow(() -> new NotFoundException(id + " is not found."))
                .toDomainUser();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public User save(User user) {
        return this.userJpaRepository.save(UserEntity.build(user)).toDomainUser();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void deleteById(Integer id) {
        try {
            this.userJpaRepository.deleteById(id);
        } catch (EmptyResultDataAccessException e) {
            // 削除しようとしたIDが存在しない
            throw new NotFoundException(e.getMessage());
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<User> findAll() {
        try {
            return this.userJpaRepository.findAll().stream().map(entity -> entity.toDomainUser()).collect(Collectors.toList());
        } catch (EmptyResultDataAccessException e) {
            // 削除しようとしたIDが存在しない
            throw new NotFoundException(e.getMessage());
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public User findByUsername(String username) {
        List<UserEntity> user = this.userJpaRepository.findByUsername(username);
        if(user.isEmpty()) {
            return null;
        }else{
            return user.get(0).toDomainUser();
        }
    }
}