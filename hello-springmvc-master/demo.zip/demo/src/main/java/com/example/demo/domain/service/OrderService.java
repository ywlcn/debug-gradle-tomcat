package com.example.demo.domain.service;

import java.util.List;

import com.example.demo.domain.object.Order;
import com.example.demo.domain.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * 注文操作のロジック
 */
@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;


    /**
     * 注文一覧
     *
     * @return 注文リスト
     */
    public List<Order> findAll() {
        return this.orderRepository.findAll();
    }
    
    /**
     * 注文一覧
     *
     * @return 注文リスト
     */
    public List<Order> findByUserID(Integer userId) {
        return this.orderRepository.findAllByUserId(userId);
    }


    /**
     * 注文検索
     *
     * @param id 検索したい注文ID
     * @return 注文
     */
    public Order findById(Integer userId, Integer orderId) {
        //return this.orderRepository.findOwnOrderById(userId, orderId);
        return this.orderRepository.findById(orderId);
    }

    /**
     * 注文作成、更新
     *
     * @param order 作成、更新した注文
     * @return 更新後の注文
     */
    public Order save(Order order) {
        return this.orderRepository.save(order);
    }

    /**
     * 注文削除
     *
     * @param id 削除したい注文ID
     */
    public void deleteById(Integer id) {
        this.orderRepository.deleteById(id);
    }
}