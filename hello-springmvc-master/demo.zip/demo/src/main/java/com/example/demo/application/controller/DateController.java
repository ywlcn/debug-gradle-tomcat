package com.example.demo.application.controller;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.application.resource.DateResponse;
import com.example.demo.application.resource.ErrorResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;

/**
 * ユーザ操作のコントローラ
 */
@RestController
@RequiredArgsConstructor
@RequestMapping(path = "/v1/date")
@Api(tags = "日付")
public class DateController {

    /**
     * 閏年判断
     *
     * @return ユーザリスト
     */
    @ApiResponses({ @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @GetMapping("/{date}")
    @ResponseStatus(HttpStatus.OK)
    public DateResponse testLeap(@PathVariable("date") @DateTimeFormat(pattern = "yyyy-MM-dd") Date date) {
        int year = date.getYear();
        if ((((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0))) {
            return new DateResponse(true);
        } else {
            return new DateResponse(false);
        }
    }
}