package com.example.demo.domain.service;

import java.util.List;

import com.example.demo.domain.object.User;
import com.example.demo.domain.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * ユーザ操作のロジック
 */
@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;


    /**
     * ユーザ一覧
     *
     * @return ユーザリスト
     */
    public List<User> findAll() {
        return this.userRepository.findAll();
    }


    /**
     * ユーザ検索
     *
     * @param id 検索したいユーザID
     * @return ユーザ
     */
    public User findById(Integer id) {
        return this.userRepository.findById(id);
    }

    /**
     * ユーザ作成、更新
     *
     * @param user 作成、更新したユーザ
     * @return 更新後のユーザ
     */
    public User save(User user) {
        return this.userRepository.save(user);
    }

    /**
     * ユーザ削除
     *
     * @param id 削除したいユーザID
     */
    public void deleteById(Integer id) {
        this.userRepository.deleteById(id);
    }
}