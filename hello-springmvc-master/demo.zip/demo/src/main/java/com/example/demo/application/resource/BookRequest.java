package com.example.demo.application.resource;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * リクエストボディのマッピング用クラス
 */
@Data
@ApiModel(value = "本情報（IDなし）")
public class BookRequest {

    @ApiModelProperty(value = "本名")
    private String bookname;
    
    @ApiModelProperty(value = "バーコード")
    private String barcode;
    
    @ApiModelProperty(value = "価格")
    private Integer price;

}