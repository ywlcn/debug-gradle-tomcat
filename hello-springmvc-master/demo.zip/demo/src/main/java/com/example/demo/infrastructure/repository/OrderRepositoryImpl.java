package com.example.demo.infrastructure.repository;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.domain.exception.NotFoundException;
import com.example.demo.domain.object.Order;
import com.example.demo.domain.repository.OrderRepository;
import com.example.demo.infrastructure.entity.OrderEntity;

import lombok.RequiredArgsConstructor;

/**
 * 永続化の実装クラス ドメインオブジェクトをEntityに変換してJPAをラップする
 */
@Repository
@RequiredArgsConstructor
public class OrderRepositoryImpl implements OrderRepository{
	
	private final OrderJpaRepository orderJpaRepository;
	
	/**
     * {@inheritDoc}
     */
    @Override
    public Order findById(Integer id) {
        return this.orderJpaRepository.findById(id).orElseThrow(() -> new NotFoundException(id + " is not found."))
                .toDomainOrder();
    }
    
//	/**
//     * {@inheritDoc}
//     */
//    @Override
//    public Order findOwnOrderById(Integer userId, Integer orderId) {
//        return this.orderJpaRepository.findOwnOrderById(userId, orderId).orElseThrow(() -> new NotFoundException(orderId + " is not found."))
//                .toDomainOrder();
//    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Order save(Order Order) {
        return this.orderJpaRepository.save(OrderEntity.build(Order)).toDomainOrder();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void deleteById(Integer id) {
        try {
            this.orderJpaRepository.deleteById(id);
        } catch (EmptyResultDataAccessException e) {
            // 削除しようとしたIDが存在しない
            throw new NotFoundException(e.getMessage());
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<Order> findAll() {
        try {
            return this.orderJpaRepository.findAll().stream().map(entity -> entity.toDomainOrder()).collect(Collectors.toList());
        } catch (EmptyResultDataAccessException e) {
            // 削除しようとしたIDが存在しない
            throw new NotFoundException(e.getMessage());
        }
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public List<Order> findAllByUserId(Integer userId) {
        try {
            return this.orderJpaRepository.findAll().stream().filter(entity -> entity.getUser().getId() == userId).map(entity -> entity.toDomainOrder()).collect(Collectors.toList());
        } catch (EmptyResultDataAccessException e) {
            // 削除しようとしたIDが存在しない
            throw new NotFoundException(e.getMessage());
        }
    }
}
