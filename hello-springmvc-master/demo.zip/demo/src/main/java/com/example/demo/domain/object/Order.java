package com.example.demo.domain.object;

import lombok.Builder;
import lombok.Data;

/**
 * 注文
 */
@Data
@Builder
public class Order {
	private Integer id;
	
	private User user;
	
	private Book book;
}
