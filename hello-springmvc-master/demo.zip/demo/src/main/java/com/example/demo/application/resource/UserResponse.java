package com.example.demo.application.resource;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * ユーザ
 */
@Data
@Builder
@ApiModel(value = "ユーザ情報（パスワードなし）")
public class UserResponse {

    /**
     * ユーザID
     */
    @ApiModelProperty(value = "ユーザID")
    private Integer id;

    /**
     * ユーザ名
     */
    @ApiModelProperty(value = "ユーザ名")
    private String username;

    /**
     * 氏名
    */
    @ApiModelProperty(value = "氏名")
    private String name;

    /**
     * 残高
    */
    @ApiModelProperty(value = "残高")
    private Double balance;

}