package com.example.demo.domain.repository;

import java.util.List;

import com.example.demo.domain.object.User;

/**
 * インフラ層とのインタフェース
 */
public interface UserRepository {

    /**
     * ユーザ一覧
     * @return
     */
    List<User> findAll();

    /**
     * ユーザ検索
     *
     * @param id 検索したいユーザID
     * @return ユーザ
     */
    User findById(Integer id);

    /**
     * ユーザ作成、更新
     *
     * @param user 作成、更新したユーザ
     * @return 更新後のユーザ
     */
    User save(User user);

    /**
     * ユーザ削除
     *
     * @param id 削除したいユーザID
     */
    void deleteById(Integer id);

    /**
     * ユーザ名をキーワードとして検索する
     * @param username　ユーザ名
     * @return　ユーザ情報
     */
	User findByUsername(String username);
}