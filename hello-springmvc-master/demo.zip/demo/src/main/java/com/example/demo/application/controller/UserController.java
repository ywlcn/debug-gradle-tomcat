package com.example.demo.application.controller;

import java.util.List;
import java.util.stream.Collectors;

import com.example.demo.application.resource.ErrorResponse;
import com.example.demo.application.resource.UserPasswordRequest;
import com.example.demo.application.resource.UserProfileRequest;
import com.example.demo.application.resource.UserRequest;
import com.example.demo.application.resource.UserResponse;
import com.example.demo.domain.object.User;
import com.example.demo.domain.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;

/**
 * ユーザ操作のコントローラ
 */
@RestController
@RequiredArgsConstructor
@RequestMapping(path = "/v1/users")
@Api(tags = "ユーザー")
public class UserController {

    private final UserService userService;

    @Autowired
    private PasswordEncoder bcryptEncoder;

    /**
     * ユーザ一覧
     *
     * @return ユーザリスト
     */
    @ApiResponses({ @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "ユーザ一覧")
    @GetMapping("/")
    @ResponseStatus(HttpStatus.OK)
    public List<UserResponse> findAll() {
        List<User> users = this.userService.findAll();
        return users.stream().map(user -> {
            return UserResponse.builder().id(user.getId()).username(user.getUsername()).name(user.getName())
                    .balance(user.getBalance()).build();
        }).collect(Collectors.toList());
    }

    /**
     * ユーザ検索
     *
     * @param id 検索したいユーザID
     * @return ユーザ
     */
    @ApiResponses({ @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "ユーザ検索")
    @GetMapping("{id}")
    @ResponseStatus(HttpStatus.OK)
    public UserResponse findById(@PathVariable("id") Integer id) {
        User user = this.userService.findById(id);
        return UserResponse.builder().id(user.getId()).username(user.getUsername()).name(user.getName())
                .balance(user.getBalance()).build();
    }

    /**
     * ユーザ作成
     *
     * @param userBody リクエストボディ
     * @return 新規ユーザ
     */
    @ApiResponses({ @ApiResponse(code = 400, message = "Bad Request", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "ユーザ新規")
    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public UserResponse save(@RequestBody @Validated UserRequest userReq) {
        User user = User.builder().id(null).username(userReq.getUsername())
                .password(bcryptEncoder.encode(userReq.getPassword())).name(userReq.getName())
                .balance(userReq.getBalance()).build();
        user = this.userService.save(user);
        return UserResponse.builder().id(user.getId()).username(user.getUsername()).name(user.getName())
                .balance(user.getBalance()).build();
    }

    /**
     * ユーザ情報（パスワード除外）更新
     *
     * @param userBody リクエストボディ
     * @return 更新後のユーザ
     */
    @ApiResponses({ @ApiResponse(code = 400, message = "Bad Request", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "ユーザ情報（パスワード除外）更新")
    @PutMapping("{id}")
    @ResponseStatus(HttpStatus.OK)
    public UserResponse save(@PathVariable("id") Integer id, @RequestBody @Validated UserProfileRequest userReq) {
        User user = User.builder().id(id).username(userReq.getUsername()).password(null).name(userReq.getName())
                .balance(userReq.getBalance()).build();
        user = this.userService.save(user);
        return UserResponse.builder().id(user.getId()).username(user.getUsername()).name(user.getName())
                .balance(user.getBalance()).build();
    }

    /**
     * パスワード更新
     *
     * @param id               ユーザID
     * @param userPasswordBody 新しいパスワード
     * @return 更新後のユーザ
     */
    @ApiResponses({ @ApiResponse(code = 400, message = "Bad Request", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "ユーザのパスワード更新")
    @PutMapping("password/{id}")
    @ResponseStatus(HttpStatus.OK)
    public UserResponse save(@PathVariable("id") Integer id,
            @RequestBody @Validated UserPasswordRequest userPasswordBody) {
        User user = this.userService.findById(id);
        user.setPassword(bcryptEncoder.encode(userPasswordBody.getPassword()));
        user = this.userService.save(user);
        return UserResponse.builder().id(user.getId()).username(user.getUsername()).name(user.getName())
                .balance(user.getBalance()).build();
    }

    /**
     * ユーザ削除
     *
     * @param id 削除したいユーザID
     */
    @ApiResponses({ @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "ユーザ削除")
    @DeleteMapping("{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable("id") Integer id) {
        this.userService.deleteById(id);
    }
}