package com.example.demo.domain.repository;

import java.util.List;

import com.example.demo.domain.object.Book;

/**
 * インフラ層とのインタフェース
 */
public interface BookRepository {

    /**
     * 本一覧
     * @return
     */
    List<Book> findAll();

    /**
     * 本検索
     *
     * @param id 検索したい本ID
     * @return 本
     */
    Book findById(Integer id);

    /**
     * 本作成、更新
     *
     * @param Book 作成、更新した本
     * @return 更新後の本
     */
    Book save(Book book);

    /**
     * 本削除
     *
     * @param id 削除したい本ID
     */
    void deleteById(Integer id);

}