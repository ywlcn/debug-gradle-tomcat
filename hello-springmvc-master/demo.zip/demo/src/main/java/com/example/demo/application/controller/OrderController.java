package com.example.demo.application.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.application.resource.ErrorResponse;
import com.example.demo.application.resource.OrderRequest;
import com.example.demo.application.resource.OrderResponse;
import com.example.demo.domain.object.Book;
import com.example.demo.domain.object.Order;
import com.example.demo.domain.object.User;
import com.example.demo.domain.service.BookService;
import com.example.demo.domain.service.JwtUserDetailsService;
import com.example.demo.domain.service.OrderService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;

/**
 * 注文操作のコントローラ
 */
@RestController
@RequiredArgsConstructor
@RequestMapping(path = "/v1/orders")
@Api(tags = "注文")
public class OrderController {

    private final OrderService orderService;
    private final BookService bookService;
    private final JwtUserDetailsService jwtUserService;
    
    /**
             * 注文一覧
     *
     * @return 注文リスト
     */
    @ApiResponses({ @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "注文一覧")
    @GetMapping("/")
    @ResponseStatus(HttpStatus.OK)
    public List<OrderResponse> findAll() {
    	// ログインユーザを取得
    	User loginUser = jwtUserService.UsergetLoginUser();

    	// 該当ユーザの注文一覧
        List<Order> orders = this.orderService.findByUserID(loginUser.getId());
        return orders.stream().map(order-> OrderResponse.builder().id(order.getId()).bookid(order.getBook()
        		.getId()).userid(order.getUser().getId()).build()).collect(Collectors.toList());
    }

    /**
             * 注文検索
     *
     * @param id 検索したい注文ID
     * @return 注文
     */
    @ApiResponses({ @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "注文検索")
    @GetMapping("{id}")
    @ResponseStatus(HttpStatus.OK)
    public OrderResponse findById(@PathVariable("id") Integer id) {
    	// ログインユーザを取得
    	User loginUser = jwtUserService.UsergetLoginUser();

    	// 該当ユーザの注文検索
        Order order = this.orderService.findById(loginUser.getId(), id);
        return OrderResponse.builder().id(order.getId()).bookid(order.getBook().getId()).userid(order.getUser()
        		.getId()).build();
    }

    /**
     * 注文作成
     *
     * @param userBody リクエストボディ
     * @return 新規注文
     */
    @ApiResponses({ @ApiResponse(code = 400, message = "Bad Request", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "注文新規")
    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public OrderResponse save(@RequestBody @Validated OrderRequest orderReq) {
    	// ログインユーザを取得
    	User loginUser = jwtUserService.UsergetLoginUser();
    	
    	// 注文作成
    	Book book = this.bookService.findById(orderReq.getBookid());
        Order order = Order.builder().id(null).user(loginUser).book(book).build();
        order = this.orderService.save(order);
        return OrderResponse.builder().id(order.getId()).bookid(book.getId()).userid(loginUser.getId()).build();
    }

    /**
     * 注文情報更新
     *
     * @param userBody リクエストボディ
     * @return 更新後の注文
     */
    @ApiResponses({ @ApiResponse(code = 400, message = "Bad Request", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "注文情報更新")
    @PutMapping("{id}")
    @ResponseStatus(HttpStatus.OK)
    public OrderResponse save(@PathVariable("id") Integer id, @RequestBody @Validated OrderRequest orderReq) {
    	// ログインユーザを取得
    	User loginUser = jwtUserService.UsergetLoginUser();
    	// 注文情報更新
    	Book book = this.bookService.findById(orderReq.getBookid());
        Order order = Order.builder().id(id).book(book).user(loginUser).build();
        order = this.orderService.save(order);
        return OrderResponse.builder().id(order.getId()).bookid(book.getId()).userid(loginUser.getId()).build();
    }

    /**
     * 注文削除
     *
     * @param id 削除したい注文ID
     */
    @ApiResponses({ @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "注文削除")
    @DeleteMapping("{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable("id") Integer id) {
    	// ログインユーザを取得
    	//User loginUser = jwtUserService.UsergetLoginUser();
        this.orderService.deleteById(id);
    }
}