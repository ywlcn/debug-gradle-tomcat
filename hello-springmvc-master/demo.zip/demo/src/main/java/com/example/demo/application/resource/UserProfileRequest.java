package com.example.demo.application.resource;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * リクエストボディのマッピング用クラス
 */
@Data
@ApiModel(value = "ユーザ情報（ID、パスワードなし）")
public class UserProfileRequest {

    @NotBlank
    @ApiModelProperty(value = "ユーザ名")
    private String username;

    @NotBlank
    @ApiModelProperty(value = "氏名")
    private String name;

    @NotNull
    @ApiModelProperty(value = "残高")
    private Double balance;
}