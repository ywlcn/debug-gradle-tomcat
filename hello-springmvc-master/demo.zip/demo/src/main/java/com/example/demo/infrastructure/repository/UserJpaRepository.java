package com.example.demo.infrastructure.repository;

import java.util.List;

import com.example.demo.infrastructure.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * JPAを利用するためのインタフェース
 */
public interface UserJpaRepository extends JpaRepository<UserEntity, Integer> {

    List<UserEntity> findByUsername(String username);
}