package com.example.demo.domain.service;

import java.util.List;

import com.example.demo.domain.object.Book;
import com.example.demo.domain.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * 本操作のロジック
 */
@Service
@RequiredArgsConstructor
public class BookService {

    private final BookRepository bookRepository;


    /**
     * 本一覧
     *
     * @return 本リスト
     */
    public List<Book> findAll() {
        return this.bookRepository.findAll();
    }


    /**
     * 本検索
     *
     * @param id 検索したい本ID
     * @return 本
     */
    public Book findById(Integer id) {
        return this.bookRepository.findById(id);
    }

    /**
     * 本作成、更新
     *
     * @param book 作成、更新した本
     * @return 更新後の本
     */
    public Book save(Book book) {
        return this.bookRepository.save(book);
    }

    /**
     * 本削除
     *
     * @param id 削除したい本ID
     */
    public void deleteById(Integer id) {
        this.bookRepository.deleteById(id);
    }
}