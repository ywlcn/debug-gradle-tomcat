package com.example.demo.application.resource;

import javax.validation.constraints.NotBlank;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * リクエストボディのマッピング用クラス
 */
@Data
@ApiModel(value = "パスワード")
public class UserPasswordRequest {

    @NotBlank
    @ApiModelProperty(value = "パスワード")
    private String password;

}