package com.example.demo.application.controller;

import com.example.demo.application.resource.JwtRequest;
import com.example.demo.application.resource.JwtResponse;
import com.example.demo.application.resource.UserRequest;
import com.example.demo.application.resource.UserResponse;
import com.example.demo.config.JwtTokenUtil;
import com.example.demo.domain.object.User;
import com.example.demo.domain.service.JwtUserDetailsService;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import lombok.RequiredArgsConstructor;

@RestController
@CrossOrigin
@RequiredArgsConstructor
@RequestMapping(path = "/v1/auth")
@Api(tags = "認証")
public class JwtAuthenticationController {

	private final AuthenticationManager authenticationManager;

	private final JwtTokenUtil jwtTokenUtil;

	private final JwtUserDetailsService userDetailsService;

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public JwtResponse createAuthenticationToken(@RequestBody JwtRequest authenticationRequest) throws Exception {
		
		authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());
		
		final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUsername());
		final String token = jwtTokenUtil.generateToken(userDetails);
		return new JwtResponse(token);
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public UserResponse saveUser(@RequestBody UserRequest userReq) throws Exception {
		// リクエスト　→　ドメイン層オブジェクト
		User user = User.builder()
			.id(null)
			.username(userReq.getUsername())
			.password(userReq.getPassword())
			.name(userReq.getName())
			.balance(userReq.getBalance())
			.build();
		// ドメイン層処理
		user = userDetailsService.save(user);
		// ドメイン層オブジェクト　→　レスポンス
		return UserResponse.builder()
			.id(user.getId())
			.username(user.getUsername())
			.name(user.getName())
			.balance(user.getBalance())
			.build();
	}

	private void authenticate(String username, String password) throws Exception {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (DisabledException e) {
			throw new Exception("USER_DISABLED", e);
		} catch (BadCredentialsException e) {
			throw new Exception("INVALID_CREDENTIALS", e);
		}
	}
}
