package com.example.demo.application.resource;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Value;

@Value
@AllArgsConstructor
@ApiModel(value = "閏年判断")
public class DateResponse {

    @JsonProperty("isLeap")
    @ApiModelProperty(value = "閏年")
    private boolean leap;
}