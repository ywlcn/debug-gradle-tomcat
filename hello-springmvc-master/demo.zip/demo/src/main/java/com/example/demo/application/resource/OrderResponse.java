package com.example.demo.application.resource;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * 注文
 */
@Data
@Builder
@ApiModel(value = "注文情報")
public class OrderResponse {

    /**
     * 注文ID
     */
    @ApiModelProperty(value = "注文ID")
    private Integer id;

    /**
     * ユーザID
     */
    @ApiModelProperty(value = "ユーザID")
    private Integer userid;

    /**
     * 本ID
    */
    @ApiModelProperty(value = "本ID")
    private Integer bookid;

}