package com.example.demo.domain.object;

import lombok.Builder;
import lombok.Data;

/**
 * 本
 */
@Data
@Builder
public class Book {
    /**
     * 本ID
     */
    private Integer id;

    /**
     * 本名
     */
    private String bookname;
    
    /**
     * バーコード
     */
    private String barcode;
    
    /**
     * 価格
     */
    private Integer price;
    
    /**
     * 状態
     */
    private String status;
}
