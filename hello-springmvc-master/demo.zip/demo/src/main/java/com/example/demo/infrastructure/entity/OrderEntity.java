package com.example.demo.infrastructure.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.example.demo.domain.object.Order;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "test_orders", uniqueConstraints = @UniqueConstraint(columnNames = {"id"}))
public class OrderEntity {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private UserEntity user;
    
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "book_id")
    private BookEntity book;
    
    /**
     * ドメインオブジェクトからインスタンスを生成
     *
     * @param order ドメインオブジェクト
     * @return OrderEntity
     */
    public static OrderEntity build(Order order) {
        return OrderEntity.builder()
                .id(order.getId())
                .user(UserEntity.build(order.getUser()))
                .book(BookEntity.build(order.getBook()))
                .build();
    }

    /**
     * ドメインオブジェクトへ変換
     *
     * @return ドメインオブジェクト
     */
    public Order toDomainOrder() {
        return Order.builder()
                .id(this.id)
                .user(this.user.toDomainUser())
                .book(this.book.toDomainBook())
                .build();
    }
}
