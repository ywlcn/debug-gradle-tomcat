package com.example.demo.application.resource;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * 本
 */
@Data
@Builder
@ApiModel(value = "本情報")
public class BookResponse {

    /**
     * 本ID
     */
    @ApiModelProperty(value = "本ID")
    private Integer id;

    /**
     * 本名
     */
    @ApiModelProperty(value = "本名")
    private String bookname;
    
    /**
     * バーコード
     */
    @ApiModelProperty(value = "バーコード")
    private String barcode;
    
    /**
     * 価格
     */
    @ApiModelProperty(value = "価格")
    private Integer price;
    
    /**
     * 状態
     */
    @ApiModelProperty(value = "状態")
    private String status;
}