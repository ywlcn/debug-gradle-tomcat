package com.example.demo.domain.object;

import lombok.Builder;
import lombok.Data;

/**
 * ユーザ
 */
@Data
@Builder
public class User {

    /**
     * ユーザID
     */
    private Integer id;

    /**
     * ユーザ名
     */
    private String username;

   /**
     * パスワード
     */
    private String password;

    /**
     * 氏名
    */
    private String name;

    /**
     * 残高
    */
    private Double balance;

}