package com.example.demo;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestLog {

	  private static final Logger logger = LoggerFactory.getLogger("MyLog");

	  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		
		int i = 1;
		
		for (i = 1 ; i <= 50000 ; i ++) {
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			logger.debug("Main debug");
			logger.debug("Main debug");

			logger.debug("Main debug");

			logger.debug("Main debug");

			logger.debug("Main debugdebugdebugdebugdebugdebugdebugdebugdebugdebugdebugdebugdebugdebug");

//		    logger.info("Main info current:{}", new Date());
//		    logger.warn("Main warn");
//		    logger.error("Main error");
			
		}
			  


 
	}

}
