package com.example.demo.application.controller;

import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.application.resource.BookRequest;
import com.example.demo.application.resource.BookResponse;
import com.example.demo.application.resource.ErrorResponse;
import com.example.demo.domain.object.Book;
import com.example.demo.domain.service.BookService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;

/**
 * 本操作のコントローラ
 */
@RestController
@RequiredArgsConstructor
@RequestMapping(path = "/v1/books")
@Api(tags = "本")
public class BookController {

    private final BookService bookService;
    
    /**
     * 本一覧
     *
     * @return 本リスト
     */
    @ApiResponses({ @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "本一覧")
    @GetMapping("/")
    @ResponseStatus(HttpStatus.OK)
    public List<BookResponse> findAll() {
        List<Book> books = this.bookService.findAll();        
        return books.stream().map(book-> BookResponse.builder()
        		.id(book.getId())
        		.bookname(book.getBookname())
        		.price(book.getPrice())
        		.status(book.getStatus())
        		.build())
        		.collect(Collectors.toList());
    }

    /**
     * 本検索
     *
     * @param id 検索したい本ID
     * @return 本
     */
    @ApiResponses({ @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "本検索")
    @GetMapping("{id}")
    @ResponseStatus(HttpStatus.OK)
    public BookResponse findById(@PathVariable("id") Integer id) {
        Book book = this.bookService.findById(id);
        return BookResponse.builder()
        		.id(book.getId())
        		.bookname(book.getBookname())
        		.price(book.getPrice())
        		.barcode(book.getBarcode())
        		.status(book.getStatus())
        		.build();
    }

    /**
     * 本作成
     *
     * @param userBody リクエストボディ
     * @return 新規本
     */
    @ApiResponses({ @ApiResponse(code = 400, message = "Bad Request", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "本新規")
    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public BookResponse save(@RequestBody @Validated BookRequest bookReq) {
    	
    	// 本名中で半角有無のチェック
		String status = "OK";
		if (Pattern.matches(".*[0-9a-zA-Z_]", bookReq.getBookname())) {
			status = "NG";
		}
    	
        Book book = Book.builder()
        		.id(null)
        		.bookname(bookReq.getBookname())
        		.price(bookReq.getPrice())
        		.barcode(bookReq.getBarcode())
        		.status(status)
        		.build();
        
        book = this.bookService.save(book);
        return BookResponse.builder()
        		.id(book.getId())
        		.bookname(book.getBookname())
        		.price(book.getPrice())
        		.barcode(book.getBarcode())
        		.status(status)
        		.build();
    }

    /**
     * 本情報更新
     *
     * @param userBody リクエストボディ
     * @return 更新後の本
     */
    @ApiResponses({ @ApiResponse(code = 400, message = "Bad Request", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "本情報更新")
    @PutMapping("{id}")
    @ResponseStatus(HttpStatus.OK)
    public BookResponse save(@PathVariable("id") Integer id, @RequestBody @Validated BookRequest bookReq) {
    	
    	// 本名中で半角有無のチェック
		String status = "OK";
		if (Pattern.matches(".*[0-9a-zA-Z_]", bookReq.getBookname())) {
			status = "NG";
		}
		
        Book book = Book.builder()
        		.id(id)
        		.bookname(bookReq.getBookname())
        		.price(bookReq.getPrice())
        		.barcode(bookReq.getBarcode())
        		.status(status)
        		.build();
        
        book = this.bookService.save(book);
        return BookResponse.builder()
        		.id(book.getId())
        		.bookname(book.getBookname())
        		.price(book.getPrice())
        		.barcode(book.getBarcode())
        		.status(book.getStatus())
        		.build();
    }

    /**
     * 本削除
     *
     * @param id 削除したい本ID
     */
    @ApiResponses({ @ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class), })
    @ApiOperation(value = "本削除")
    @DeleteMapping("{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteById(@PathVariable("id") Integer id) {
        this.bookService.deleteById(id);
    }
}
